﻿New-ADUser -UserPrincipalName svcAADConnect@corp.acme.com `
           -Name svcAADConnect `
           -AccountPassword (ConvertTo-SecureString -AsPlainText -Force -String 'Pa$$w0rd') `
           -Enabled $true `
           -ChangePasswordAtLogon $false `
           -PasswordNeverExpires $true `
           -DisplayName 'svcAADConnect' `
           -Description 'Azure AD Connect Service Account' `
           -Path 'OU=ServiceAccounts,OU=ACME,DC=corp,DC=acme,DC=com' -Verbose
           