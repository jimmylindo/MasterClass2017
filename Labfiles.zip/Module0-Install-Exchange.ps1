﻿#Exctract Exchange media to ACME-EX01 c:\temp\Exchange
md -path c:\temp
Copy-Item -Path "\\acme-dc01\resources\Exchange2013-x64-cu15.exe" -Destination c:\temp
$exchangemedia = gci "c:\temp\Exchange2013-x64-cu15.exe"
New-Item -ItemType Directory -Path c:\temp\exchange
Start-Process -FilePath $ExchangeMedia.FullName -ArgumentList "/extract:C:\temp\Exchange"

#Prepare Active Directory. If you prefer to do it yourself: https://technet.microsoft.com/en-us/library/bb125224(v=exchg.150).aspx
C:\temp\exchange\Setup.exe /PrepareSchema /IAcceptExchangeServerLicenseTerms
#Before finishing schema updates you need to reboot server. Run line below and reopen PS script and continue after restart.
Restart-Computer
C:\temp\exchange\Setup.exe /PrepareAD /OrganizationName:"MyExchangeOrg" /IAcceptExchangeServerLicenseTerms

#This command executes installation of Exchange server.
C:\temp\exchange\Setup.exe /mode:Install /role:ClientAccess,Mailbox /TargetDir:"C:\Exchange Server" /IAcceptExchangeServerLicenseTerms