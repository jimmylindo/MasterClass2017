Function Import-SharePointClientSDK
{
<# 
 .Synopsis
  Load SharePoint 2013 Client SDK DLLs

 .Description
   Load SharePoint 2013 Client SDK DLLs from either the Global Assembly Cache or from the DLLs located in SharePointOnline PS module directory. It will use GAC if the DLLs are already loaded in GAC.

 .Example
  # Load the OpsMgr SDK DLLs
  Import-SharePointClientSDK

#>
    #OpsMgr 2012 R2 SDK DLLs
    $DLLPath = (Get-Module SharePointOnline).ModuleBase
    $arrDLLs = @()
    $arrDLLs += 'Microsoft.SharePoint.Client.dll'
    $arrDLLs += 'Microsoft.SharePoint.Client.Runtime.dll'
	$AssemblyVersion = "15.0.0.0"
	$AssemblyPublicKey = "71e9bce111e9429c"
    #Load SharePoint Client SDKs
    $bSDKLoaded = $true

    Foreach ($DLL in $arrDLLs)
    {
        $AssemblyName = $DLL.TrimEnd('.dll')
        If (!([AppDomain]::CurrentDomain.GetAssemblies() |Where-Object { $_.FullName -eq "$AssemblyName, Version=$AssemblyVersion, Culture=neutral, PublicKeyToken=$AssemblyPublicKey"}))
		{
			Write-verbose 'Loading Assembly $AssemblyName...'
			Try {
                $DLLFilePath = Join-Path $DLLPath $DLL
                [Void][System.Reflection.Assembly]::LoadFrom($DLLFilePath)
            } Catch {
                Write-Verbose "Unable to load $DLLFilePath. Please verify if the SDK DLLs exist in this location!"
                $bSDKLoaded = $false
            }
		}
    }
    $bSDKLoaded
}

Function New-SPOCredential
{
<# 
 .Synopsis
  Create a SharePoint Online credential that can be used authenticating to a SharePoint online site.

 .Description
  Create a SharePoint Online credential object (Microsoft.SharePoint.Client.SharePointOnlineCredentials) that can be used authenticating to a SharePoint online site hosted on Office 365.
  
 .Parameter -SPOConnection
  SharePoint Online Connection object (SMA connection or hash table).

 .Parameter -UserName
  User name to connect to the SharePoint Online site.

 .Parameter -Password
  Password to connect to the SharePoint Online site.

 .Example
  # Create a SharePoint Online Credential object using a SMA connection object named "MySPOSite":
  $SPOCred = New-SPOCredential -SPOCOnnection "MySPOSite"

 .Example
  # Create a SharePoint Online Credential object by specifying the user name and password:
  $SPOCred = New-SPOCredential -Username "you@yourcompany.com" -Password "password1234"
#>
    [CmdletBinding()]
    PARAM (
        [Parameter(ParameterSetName='SMAConnection',Mandatory=$true,HelpMessage='Please specify the SMA Connection object')][Alias('Connection','c')][Object]$SPOConnection,
        [Parameter(ParameterSetName='IndividualParameter',Mandatory=$true,HelpMessage='Please enter the user name to connect to the SharePoint Online site')][Alias('u')][String]$Username,
        [Parameter(ParameterSetName='IndividualParameter',Mandatory=$true,HelpMessage='Please enter the password to connect to the SharePoint Online site')][Alias('p')][String]$Password
    )

    #Firstly, make sure the Microsoft.SharePoint.Client.Dll and Microsoft.SharePoint.Client.Runtime.dll are loaded
	$ImportSDK = Import-SharePointClientSDK
	If ($ImportSDK -eq $false)
	{
		Write-Error "Unable to load SharePoint Client DLLs. Aborting."
		Return
	}
	
	If ($SPOConnection)
	{
		$Username = $SPOConnection.Username
		$SecurePassword = $SPOConnection.Password | ConvertTo-SecureString -AsPlainText -Force
	} else {
		$SecurePassword = $Password | ConvertTo-SecureString -AsPlainText -Force
	}
	$credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Username, $SecurePassword)
	$credential
}

Function Get-SPOListFields
{
<# 
 .Synopsis
  Get all fields from a list on a SharePoint Online site.

 .Description
  Get all fields from a list on a SharePoint Online site.
  
 .Parameter -SPOConnection
  SharePoint Online Connection object (SMA connection or hash table).

 .Parameter -SiteUrl
  SharePoint Online Site Url

 .Parameter -Username
  SharePoint Online Username

 .Parameter -Password
  SharePoint Online password

 .Parameter -List Name
  Name of the list

 .Example
  $ListFields = Get-SPOListFields -SPOConnection $SPOConnection -ListName "Test List"

 .Example
  $ListFields = Get-SPOListFields -SiteUrl "https://yourcompany.sharepoint.com" -UserName "you@yourcompany.com" -Password "password1234" -ListName "Test List"
#>
    [CmdletBinding()]
	Param(
    [Parameter(ParameterSetName='SMAConnection',Mandatory=$True,HelpMessage='Please specify the SharePointOnlineCredentials object')][Object]$SPOConnection,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the request URL')][String]$SiteUrl,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the name of the list')][String]$ListName,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the Username')][string]$Username,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the password')][string]$Password
    )

	If($SPOConnection)
	{
		$Credential = New-SPOCredential -SPOConnection $SPOConnection
		$SiteUrl = $SPOConnection.SharePointSiteURL
	} else {
		$Credential = New-SPOCredential -Username $Username -Password $Password
	}
	#Make sure the SharePoint Client SDK Runtime DLLs are loaded
	$ImportDLL = Import-SharePointClientSDK

	#Bind to site collection
	$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
	$Context.Credentials = $Credential

	#Retrieve list
	$List = $Context.Web.Lists.GetByTitle($ListName)
	$Context.Load($List)
	$Context.ExecuteQuery()

	#Get List fields
	$colListFields = $List.Fields                                                                                    
	$Context.Load($colListFields)                                                                                    
	$Context.ExecuteQuery()        

	#add fields to an array
	$ListFields = @()
	Foreach ($item in $colListFields)
	{
		$ListFields +=$item
	}
	$ListFields
}

Function Add-SPOListItem
{
<# 
 .Synopsis
  Add a list item to the SharePoint Online site.

 .Description
  Add a list item to the SharePoint Online site.
  
 .Parameter -SPOConnection
  SharePoint Online Connection object (SMA connection or hash table).

 .Parameter -SiteUrl
  SharePoint Online Site Url

 .Parameter -Username
  SharePoint Online Username

 .Parameter -Password
  SharePoint Online password

 .Parameter -ListName
  Name of the list

 .Parameter $ListFieldsValues
  A hash table containing List item that to be added.

 .Example
  $HashTableListFieldsValues= @{ "Title", "List Item Title"
	"Description", "List Item Description Text"
  }
  $AddListItem = Add-SPOListItem -SPOConnection $SPOConnection -ListName "Test List" -ListFieldsValues $HashTableListFieldsValues

 .Example
   $HashTableListFieldsValues= @{ "Title", "List Item Title"
	"Description", "List Item Description Text"
  }
  $AddListItem = Add-SPOListItem -SiteUrl "https://yourcompany.sharepoint.com" -UserName "you@yourcompany.com" -Password "password1234" -ListName "Test List" -ListFieldsValues $HashTableListFieldsValues

#>
    [CmdletBinding()]
	Param(
    [Parameter(ParameterSetName='SMAConnection',Mandatory=$True,HelpMessage='Please specify the SharePointOnlineCredentials object')][Object]$SPOConnection,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the request URL')][String]$SiteUrl,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the name of the list')][String]$ListName,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the Username')][string]$Username,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the password')][string]$Password,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the value of each list field in a hash table')][Object]$ListFieldsValues
    )

	If($SPOConnection)
	{
		$Credential = New-SPOCredential -SPOConnection $SPOConnection
		$SiteUrl = $SPOConnection.SharePointSiteURL
	} else {
		$Credential = New-SPOCredential -Username $Username -Password $Password
	}
	#Make sure the SharePoint Client SDK Runtime DLLs are loaded
	$ImportDLL = Import-SharePointClientSDK

	#Bind to site collection
	$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
	$Context.Credentials = $Credential

	#Retrieve list
	$List = $Context.Web.Lists.GetByTitle($ListName)
	$Context.Load($List)
	$Context.ExecuteQuery()

	#Adds an item to the list
	$ListItemInfo = New-Object Microsoft.SharePoint.Client.ListItemCreationInformation
	$Item = $List.AddItem($ListItemInfo)
	Try {
		Foreach ($Field in $ListFieldsValues.Keys)
		{
			$item["$Field"] = $ListFieldsValues.$Field
		}
		$Item.Update()
		$Context.ExecuteQuery()
		$bCreated= $True
	} Catch {
		Write-Error "Unable to add list item to the list $ListName`: " + "`n" + $ListFieldsValues
		$bCreated = $false
	}
	$bCreated
}

Function Get-SPOListItems
{
<# 
 .Synopsis
  Get all items from a list on a SharePoint Online site.

 .Description
  Get all items from a list on a SharePoint Online site.
  
 .Parameter -SPOConnection
  SharePoint Online Connection object (SMA connection or hash table).

 .Parameter -SiteUrl
  SharePoint Online Site Url

 .Parameter -Username
  SharePoint Online Username

 .Parameter -Password
  SharePoint Online password

 .Parameter -ListName
  Name of the list

 .Example
  $ListItems = Get-SPOListItems -SPOConnection $SPOConnection -ListName "Test List"

 .Example
  $ListItems = Get-SPOListItems -SiteUrl "https://yourcompany.sharepoint.com" -UserName "you@yourcompany.com" -Password "password1234" -ListName "Test List"

#>
    [CmdletBinding()]
	Param(
    [Parameter(ParameterSetName='SMAConnection',Mandatory=$True,HelpMessage='Please specify the SharePointOnlineCredentials object')][Object]$SPOConnection,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the request URL')][String]$SiteUrl,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the name of the list')][String]$ListName,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the Username')][string]$Username,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the password')][string]$Password
    )

	If($SPOConnection)
	{
		$Credential = New-SPOCredential -SPOConnection $SPOConnection
		$SiteUrl = $SPOConnection.SharePointSiteURL
	} else {
		$Credential = New-SPOCredential -Username $Username -Password $Password
	}
	#Make sure the SharePoint Client SDK Runtime DLLs are loaded
	$ImportDLL = Import-SharePointClientSDK

	#Bind to site collection
	$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
	$Context.Credentials = $Credential

	#Retrieve list
	$List = $Context.Web.Lists.GetByTitle($ListName)
	$Context.Load($List)
	$Context.ExecuteQuery()

	#Get List items
	#$camlQuery=  New-Object Microsoft.SharePoint.Client.CamlQuery
	#$camlQuery.ViewXML = "<View />"
	$camlQuery = [Microsoft.SharePoint.Client.CamlQuery]::CreateAllItemsQuery(10000)
	$colListItems = $list.GetItems($camlQuery)
	$context.Load($colListItems)
	$Context.ExecuteQuery()

	#add items to an array
	$ListItems = @()
	Foreach ($item in $colListItems)
	{
		$ListItem = @{}
		Foreach ($property in $item.FieldValues.keys)
		{
			$Value = $item.FieldValues.$property
			$ListItem.Add($Property, $Value)
		}
		$ListItems +=$ListItem
	}
	$ListItems
}

Function Remove-SPOListItem
{
<# 
 .Synopsis
  Delete a list item to the SharePoint Online site.

 .Description
  Delete a list item to the SharePoint Online site.
  
 .Parameter -SPOConnection
  SharePoint Online Connection object (SMA connection or hash table).

 .Parameter -SiteUrl
  SharePoint Online Site Url

 .Parameter -Username
  SharePoint Online Username

 .Parameter -Password
  SharePoint Online password

 .Parameter -ListName
  Name of the list

 .Parameter $ListItemID
  The ID of the item to be deleted

 .Example
  $DeleteListItem = Remove-SPOListItem -SPOConnection $SPOConnection -ListName "Test List" -ListItemID 1

 .Example
  $AddListItem = Add-SPOListItem -SiteUrl "https://yourcompany.sharepoint.com" -UserName "you@yourcompany.com" -Password "password1234" -ListName "Test List" -ListItemID 1
#>
    [CmdletBinding()]
	Param(
    [Parameter(ParameterSetName='SMAConnection',Mandatory=$True,HelpMessage='Please specify the SharePointOnlineCredentials object')][Object]$SPOConnection,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the request URL')][String]$SiteUrl,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the name of the list')][String]$ListName,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the Username')][string]$Username,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the password')][string]$Password,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the ID of the list item to be deleted')][int]$ListItemID
    )

	If($SPOConnection)
	{
		$Credential = New-SPOCredential -SPOConnection $SPOConnection
		$SiteUrl = $SPOConnection.SharePointSiteURL
	} else {
		$Credential = New-SPOCredential -Username $Username -Password $Password
	}
	#Make sure the SharePoint Client SDK Runtime DLLs are loaded
	$ImportDLL = Import-SharePointClientSDK

	#Bind to site collection
	$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
	$Context.Credentials = $Credential

	#Retrieve list
	$List = $Context.Web.Lists.GetByTitle($ListName)
	$Context.Load($List)
	$Context.ExecuteQuery()

	#Retrieve the list item
	Try {
		$ListItem = $List.GetItemById($ListItemID)
		$Context.Load($ListItem)
		$Context.ExecuteQuery()
		$bItemFound = $True
	} Catch {
		Write-Error "Unable to find list item with ID $ListItemID from the list $ListName."
		$bItemFound = $false
	}


	#Delete the item
	if ($bItemFound)
	{
		Try {
			$ListItem.DeleteObject()
			$Context.ExecuteQuery()
			$bRemoved= $True
		} Catch {
			Write-Error "Unable to delete the list item (ID: $ListItemID) from the list $ListName."
			$bRemoved = $false
		}
	} else {
		$bRemoved = $false
	}
	$bRemoved
}

Function Update-SPOListItem
{
<# 
 .Synopsis
  Update a list item to the SharePoint Online site.

 .Description
  UPdate a list item to the SharePoint Online site.
  
 .Parameter -SPOConnection
  SharePoint Online Connection object (SMA connection or hash table).

 .Parameter -SiteUrl
  SharePoint Online Site Url

 .Parameter -Username
  SharePoint Online Username

 .Parameter -Password
  SharePoint Online password

 .Parameter -ListName
  Name of the list

 .Parameter $ListItemID
  The ID of the item to be deleted

 .Parameter $ListFieldsValues
  A hash table containing List item that to be added.

 .Example
  $HashTableListFieldsValues= @{ "Title", "List Item Title"
	"Description", "List Item Description Text"
  }
  $UpdateListItem = Update-SPOListItem -SPOConnection $SPOConnection -ListName "Test List" -ListItemID 1 -ListFieldsValues $HashTableListFieldsValues

 .Example
   $HashTableListFieldsValues= @{ "Title", "List Item Title"
	"Description", "List Item Description Text"
  }
  $UpdateListItem = Update-SPOListItem -SiteUrl "https://yourcompany.sharepoint.com" -UserName "you@yourcompany.com" -Password "password1234" -ListName "Test List" -ListItemID 1 -ListFieldsValues $HashTableListFieldsValues

#>
    [CmdletBinding()]
	Param(
    [Parameter(ParameterSetName='SMAConnection',Mandatory=$True,HelpMessage='Please specify the SharePointOnlineCredentials object')][Object]$SPOConnection,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the request URL')][String]$SiteUrl,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the name of the list')][String]$ListName,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the Username')][string]$Username,
	[Parameter(ParameterSetName='UserNameAndPassword',Mandatory=$True,HelpMessage='Please specify the password')][string]$Password,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the ID of the list item to be deleted')][int]$ListItemID,
	[Parameter(Mandatory=$true,HelpMessage='Please specify the value of each list field in a hash table')][Object]$ListFieldsValues
    )

	If($SPOConnection)
	{
		$Credential = New-SPOCredential -SPOConnection $SPOConnection
		$SiteUrl = $SPOConnection.SharePointSiteURL
	} else {
		$Credential = New-SPOCredential -Username $Username -Password $Password
	}
	#Make sure the SharePoint Client SDK Runtime DLLs are loaded
	$ImportDLL = Import-SharePointClientSDK

	#Bind to site collection
	$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
	$Context.Credentials = $Credential

	#Retrieve list
	$List = $Context.Web.Lists.GetByTitle($ListName)
	$Context.Load($List)
	$Context.ExecuteQuery()

	#Retrieve the list item
	Try {
		$ListItem = $List.GetItemById($ListItemID)
		$Context.Load($ListItem)
		$Context.ExecuteQuery()
		$bItemFound = $True
	} Catch {
		Write-Error "Unable to find list item with ID $ListItemID from the list $ListName."
		$bItemFound = $false
	}

	#Update the list item
	if ($bItemFound)
	{
		Try {
			Foreach ($Field in $ListFieldsValues.Keys)
			{
				$ListItem["$Field"] = $ListFieldsValues.$Field
			}
			$ListItem.Update()
			$Context.ExecuteQuery()
			$bUpdated= $True
		} Catch {
			Write-Error "Unable to add list item to the list $ListName`: " + "`n" + $ListFieldsValues
			$bUpdated = $false
		}
	} else {
		$bUpdated = $false
	}
	
	$bUpdated
}
function global:Connect-SPOSite {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true, ValueFromPipeline=$true, Position=0)]
        $Url
    )

    begin {
        [System.Reflection.Assembly]::LoadFile("C:\Program Files\Common Files\microsoft shared\Web Server Extensions\15\ISAPI\Microsoft.SharePoint.Client.dll") | Out-Null
        [System.Reflection.Assembly]::LoadFile("C:\Program Files\Common Files\microsoft shared\Web Server Extensions\15\ISAPI\Microsoft.SharePoint.Client.Runtime.dll") | Out-Null
    }
    process {
        if ($global:spoCred -eq $null) {
            $cred = Get-Credential -Message "Enter your credentials for SharePoint Online:"
            $global:spoCred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($cred.UserName, $cred.Password)
        }
        $ctx = New-Object Microsoft.SharePoint.Client.ClientContext $Url
        $ctx.Credentials = $spoCred

        if (!$ctx.ServerObjectIsNull.Value) { 
            Write-Host "Connected to site: '$Url'" -ForegroundColor Green
        }
        return $ctx
    }
    end {
    }
}