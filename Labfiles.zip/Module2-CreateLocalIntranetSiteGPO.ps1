﻿$Site = "{0}" -f (Get-DnsServerZone | where-object {$_.ZoneName -match "o365ready"}).ZoneName
$GPO = New-GPO -Name "Internet Explorer - Local Intranet Sites" 
Set-GPPrefRegistryValue -Name $gpo.DisplayName `
                        -Context User `
                        -Key "HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Internet Settings\ZoneMap\Domains\$Site" `
                        -ValueName "https" `
                        -Value 1 `
                        -Action Create `
                        -Type DWord 
New-GPLink -Name $gpo.DisplayName -Target "OU=Users,OU=ACME,DC=corp,DC=acme,DC=com"
