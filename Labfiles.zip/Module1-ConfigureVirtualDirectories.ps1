﻿
$server='ACME-EX01'
$domainname='lab22307.o365ready.com'


Set-ClientAccessServer $server -AutoDiscoverServiceInternalUri https://autodiscover.$domainname/Autodiscover/Autodiscover.xml
Get-OutlookAnywhere -Server $Server | Set-OutlookAnywhere -ExternalHostname "anywhere.$domainname" -ExternalClientsRequireSsl $true  -DefaultAuthenticationMethod Negotiate
Get-OwaVirtualDirectory -Server $server | Set-OwaVirtualDirectory -ExternalUrl https://webmail.$domainname/owa -InternalUrl https://webmail.$domainname/owa
Get-EcpVirtualDirectory -Server $server | Set-EcpVirtualDirectory -ExternalUrl https://webmail.$domainname/ecp -InternalUrl https://webmail.$domainname/ecp
Get-ActiveSyncVirtualDirectory -Server $server | Set-ActiveSyncVirtualDirectory -ExternalUrl https://webmail.$domainname/Microsoft-Server-ActiveSync -InternalUrl https://webmail.$domainname/Microsoft-Server-ActiveSync
Get-WebServicesVirtualDirectory -Server $server | Set-WebServicesVirtualDirectory -ExternalUrl https://webmail.$domainname/EWS/Exchange.asmx -InternalUrl https://webmail.$domainname/EWS/Exchange.asmx
Get-OabVirtualDirectory -Server $server | Set-OabVirtualDirectory -ExternalUrl https://webmail.$domainname/OAB -InternalUrl https://webmail.$domainname/OAB











