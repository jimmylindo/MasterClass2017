﻿$Credentials = Get-Credential
Connect-MsolService -Credential $Credentials

$domain = get-adforest |select upnsuffixes -ExpandProperty upnsuffixes
Confirm-MsolDomain -DomainName $domain