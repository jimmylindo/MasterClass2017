﻿$CertToExport = Get-ChildItem Cert:\LocalMachine\My | Where-Object {$_.Subject -match "o365ready"}
$CertPath = "C:\Temp\cert.pfx" 
$Machines = "ACME-ADFS01","ACME-ADFS02","ACME-WAP01"
$Password = (ConvertTo-SecureString -AsPlainText -Force -String 'Pa$$w0rd')
Export-PfxCertificate –Cert $CertToExport –FilePath $CertPath -Password $Password -Force

$Machines | ForEach-Object -Process { 
    $destination = '\\{0}\c$\Temp' -f $_
    Copy-Item $CertPath -Destination $destination
}

Invoke-Command -ComputerName $Machines -ScriptBlock {
    Import-PfxCertificate -Exportable `
                          -FilePath $using:certpath `
                          -Password $using:password `
                          -CertStoreLocation Cert:\LocalMachine\My `
                          -Confirm:$false 
}

