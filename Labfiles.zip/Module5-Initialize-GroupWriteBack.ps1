﻿Import-Module "C:\Program Files\Microsoft Azure Active Directory Connect\AdPrep\AdSyncPrep.psm1"
$accountName = "corp\SVCAADConnect"
$cloudGroupOU = "OU=Groups,OU=ACME,DC=corp,DC=acme,DC=com"
Initialize-ADSyncGroupWriteBack -AdConnectorAccount $accountName -GroupWriteBackContainerDN $cloudGroupOU

