﻿#Connect to Exchange Online
$UserCredential = Get-Credential
$Session = New-PSSession -ConfigurationName Microsoft.Exchange `
-ConnectionUri https://outlook.office365.com/powershell-liveid/ `
-Credential $UserCredential -Authentication Basic -AllowRedirection
Import-PSSession $Session

$MigrationEndpoint = Get-MigrationEndpoint
$TargeDeliveryDomain= 'acme000.mail.onmicrosoft.com'
$NotificationAddress= 'john.doe@acme000.onmicrosoft.com'
$CsvFile="C:\labfiles\Batch1.csv"

New-MigrationBatch -Name "Batch1" -SourceEndpoint $MigrationEndpoint.Identity -TargetDeliveryDomain $TargeDeliveryDomain `
                   -BadItemLimit 10 -NotificationEmails $NotificationAddress -CSVData ([System.IO.File]::ReadAllBytes($CsvFile)) -AutoStart

