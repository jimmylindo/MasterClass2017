﻿$Name = "ACME-HW"
$EndPoint = "https://we-agentservice-prod-1.azure-automation.net/"
$Token = "EL2rYrIBo1Wl597AAmKeicQ"

Import-Module (Get-ChildItem -Path "C:\Program Files\Microsoft Monitoring Agent\Agent\AzureAutomation\" -Recurse -Filter HybridRegistration.psd1).FullName

Add-HybridRunbookWorker –Name $Name -EndPoint $EndPoint -Token $Token -Verbose