﻿$domainname='lab19748.o365ready.com'
New-ExchangeCertificate -GenerateRequest -SubjectName "c=SE, o=A company that makes everything, cn=webmail.$domainname" `
                        -DomainName anywhere.$domainname , autodiscover.$domainname, smtp.$domainname, pop.$domainname, imap.$domainname, sts.$domainname, $domainname `
                        -PrivateKeyExportable $true