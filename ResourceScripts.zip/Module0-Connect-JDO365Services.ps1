﻿    [CmdletBinding(SupportsShouldProcess=$true,DefaultParameterSetName='SpecificServices')]
    param (
        [Parameter(Mandatory=$false)] 
        [System.Management.Automation.PSCredential]$Credential = (Get-Credential -Message "Enter your admin credentials"),
        [ValidateSet("AAD", "AADRMS","EXO","LYO","SPO")]
        [Parameter(ParameterSetName='SpecificServices')]
        [string[]]$Services = "EXO",
        [Parameter(ParameterSetName='AllServices')]
        [switch]$All
    )
    begin {
        #Clean up existing PS sessions
        Get-PSSession | Remove-PSSession
    } process {
        if ($Services -eq "EXO" -or $All) {
            try {
                $Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $Credential -Authentication Basic -AllowRedirection
                Import-PSSession $Session -AllowClobber -DisableNameChecking -Verbose:$false | Out-Null
                Write-Output "Successfully connected to Exchange Online."
            } catch {
                Write-Warning "Error connecting to Exchange Online.`r`n$_"
            }  
        }
        if ($Services -eq "AAD" -or $All) {
            try {
                Connect-MsolService -Credential $Credential
                Write-Output "Successfully connected to Azure AD."
            } catch {
                Write-Warning "Error connecting to Azure AD.`r`n$_"
            }    
        }
        if ($Services -eq "SPO" -or $All) {
            try {
                $Uri = 'https://{0}-admin.sharepoint.com' -f $Credential.UserName.Split("@").split(".")[1]
                Connect-SPOService -Url $Uri -Credential $Credential
                Write-Output "Successfully connected to SharePoint Online."
            } catch {
                Write-Warning "Error connecting to SharePoint Online.`r`n$_"
            }    
        }
        if ($Services -eq "LYO" -or $All) {
            try {
                $lyncSession = New-CsOnlineSession -Credential $Credential
                Import-PSSession $lyncSession -DisableNameChecking -AllowClobber -Verbose:$false | Out-Null
                Write-Output "Successfully connected to Lync Online."
            } catch {
                Write-Warning "Error connecting to Lync Online.`r`n$_"
            }    
        }
        if ($Services -eq "AADRMS" -or $All) {
            try {
                Connect-AadrmService -Credential $Credential
                Write-Output "Successfully connected to Azure AD RMS."
            } catch {
                Write-Warning "Error connecting to Azure AD RMS.`r`n$_"
            }    
        }
    }
