﻿#Download and install EWS managed API if not present
\\acme-dc01\resources\Module0-Get-MasterClassDownloadsWithoutIE.ps1 -Tool EWSManagedAPI

$Installation = Start-Process -FilePath "msiexec.exe" -ArgumentList "/i c:\temp\EwsManagedApi.msi /qn" -Wait -PassThru
Write-Output "Successfully installed EWS managed api with ExitCode $($Installation.ExitCode)"

$EwsAddress = "https://webmail.labXXXXX.o365ready.com/EWS/Exchange.asmx"

function Populate-TestMailboxes {

######################################################################################################
#                                                                                                    #
# Name:        Populate-TestMaiboxByDate.ps1                                                         #
#                                                                                                    #
# Version:     1.0                                                                                   #
#                                                                                                    #
# Description: Uses Exchange Impersonation to populate a mailbox with test emails spread out over a  #
#              date range for the purpose of testing date-specific functions such as Retention       #
#              Policies and OST caching.                                                             #
#                                                                                                    #
# Author:      Joe Palarchio                                                                         #
#                                                                                                    #
# Usage:       Additional information on the usage of this script can found at the following         #
#              blog post:  http://blogs.perficient.com/microsoft/?p=28214                            #
#                                                                                                    #
# Disclaimer:  This script is provided AS IS without any support. Please test in a lab environment   #
#              prior to production use.                                                              #
#                                                                                                    #
######################################################################################################


<#
	.PARAMETER  TargetMailbox
		The SMTP address for the mailbox that you want to populate.

	.PARAMETER  NumDaysBack
		The number of days back from the current date to start populating messages.  Default
        	value is 120 days.

	.PARAMETER  MsgsPerDay
		The number of messages to create for each day.  Default value is 5 messages per day.
		
	.PARAMETER  MsgSize
		The size of the attachment for the message.  Default value is 100kb.
		
	.PARAMETER  AutoD
		If specified as $True, Autodiscover is used to determine the EWS endpoint.  Default
        	value is $True.

	.PARAMETER  EwsUri
		EWS endpoint for target mailbox.  Default value is to use Office 365 if not using Autodiscover.

	.PARAMETER  ApiPath
		Location of EWS API.  Default path is "C:\Program Files\Microsoft\Exchange\
        	Web Services\2.2\Microsoft.Exchange.WebServices.dll".

	.PARAMETER  Version
		Exchange version to be used by EWS.  Default is "Exchange2013_SP1" and likely
        	does not need to be changed.


	.EXAMPLE
		.\Populate-TestMailbox.ps1 -TargetMailbox test.user@iwitl.com -AutoD $true -NumDaysBack 365 -MsgsPerDay 10 -MsgSize 200kb
#>

Param(
    [Parameter(Mandatory=$True)]
        [string]$TargetMailbox,
    [Parameter(Mandatory=$False)]
        [int]$NumDaysBack = 10,
    [Parameter(Mandatory=$False)]
        [int]$MsgsPerDay = 1,
    [Parameter(Mandatory=$False)]
        [System.Int64]$MsgSize = 10kb,
    [Parameter(Mandatory=$False)]
        [string]$AutoD = $True,
    [Parameter(Mandatory=$False)]
        [string]$EwsUri = "https://mail.office365.com/ews/exchange.asmx",
    [Parameter(Mandatory=$False)]
        [string]$ApiPath = "C:\Program Files\Microsoft\Exchange\Web Services\2.2\Microsoft.Exchange.WebServices.dll",
    [Parameter(Mandatory=$False)]
        [string]$Version = "Exchange2013_SP1"
)
$AdminUsername = 'corp\sysadmin'
$AdminPassword = (ConvertTo-SecureString -AsPlainText 'Ma$tercla$$' -Force)
$ImpersonationCreds = (New-Object System.Management.Automation.PSCredential -ArgumentList $AdminUsername, $AdminPassword)


Add-Type -Path $ApiPath

$ExchangeVersion = [Microsoft.Exchange.WebServices.Data.ExchangeVersion]::$Version
$Service = New-Object Microsoft.Exchange.WebServices.Data.ExchangeService($ExchangeVersion)

$Creds = New-Object System.Net.NetworkCredential($ImpersonationCreds.UserName, $ImpersonationCreds.Password)   
$Service.Credentials = $Creds

if ($AutoD -eq $True) {
    $Service.AutodiscoverUrl($TargetMailbox,{$True})  
    "EWS URI = " + $Service.url
}
else {
    $Uri=[system.URI] $EwsUri
    $Service.Url = $uri
}

$Service.ImpersonatedUserId = New-Object Microsoft.Exchange.WebServices.Data.ImpersonatedUserId([Microsoft.Exchange.WebServices.Data.ConnectingIdType]::SmtpAddress, $TargetMailbox)

$PR_MESSAGE_DELIVERY_TIME = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x0E06, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime)
$PR_CLIENT_SUBMIT_TIME = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(0x0039, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::SystemTime)
$PR_Flags = New-Object Microsoft.Exchange.WebServices.Data.ExtendedPropertyDefinition(3591, [Microsoft.Exchange.WebServices.Data.MapiPropertyType]::Integer);  

$InboxFolder= New-Object Microsoft.Exchange.WebServices.Data.FolderId([Microsoft.Exchange.WebServices.Data.WellKnownFolderName]::Inbox,$TargetMailbox) 
$Inbox = [Microsoft.Exchange.WebServices.Data.Folder]::Bind($Service,$InboxFolder)

$Attachment = New-Object System.IO.FileStream $Env:Temp\test.txt, Create, ReadWrite
$Attachment.SetLength($MsgSize)
$Attachment.Close()

[datetime]$StartDate = Get-Date

for($i=0; $i -lt $NumDaysBack; $i++) {
    for($j=0; $j -lt $MsgsPerDay; $j++) {
        $Message = New-Object Microsoft.Exchange.WebServices.Data.EmailMessage($Service)
        $Message.Subject = "Date / Time Test Day #" + ($i+1)
        $Message.Body = "This is a test message used to test date operations on a mailbox."
        $Message.From = $TargetMailbox
        $Message.ToRecipients.Add($TargetMailbox) | Out-Null
        $Message.SetExtendedProperty($PR_Flags,"1")
        $Message.SetExtendedProperty($PR_MESSAGE_DELIVERY_TIME, $StartDate.AddDays($i * -1))
        $Message.SetExtendedProperty($PR_CLIENT_SUBMIT_TIME, $StartDate.AddDays($i * -1))
        $Message.Attachments.AddFileAttachment($attachment.Name) | Out-Null
        $Message.Save($Inbox.Id)
    }
    Write-Progress -activity "Creating Messages..." -status "Day $i of $NumDaysBack of user $TargetMailbox" -percentcomplete (($i/$NumDaysBack)*100)
}
}
Get-ADUser -Filter {proxyaddresses -like "*@*"} -Properties mail -SearchBase "OU=ACME,DC=corp,DC=acme,DC=com" | ForEach-Object -Process {
    Populate-TestMailboxes -TargetMailbox $_.Mail -EwsUri $EwsAddress
}