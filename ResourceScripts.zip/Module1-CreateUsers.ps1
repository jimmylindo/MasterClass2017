﻿#Enable Mailboxes on all users
$UPN = (Get-ADForest | select -ExpandProperty UPNSuffixes)
Set-ADUser -Identity alpast -UserPrincipalName "alp.astor@$upn"
$ou = "OU=Users,OU=ACME,DC=corp,DC=acme,DC=com"
Get-User -OrganizationalUnit $ou| Enable-Mailbox 
#Create Room Mailboxes
1..5 | ForEach-Object {
            New-Mailbox -Room -Name "HQ Conference Room $_" -OrganizationalUnit $OU
}
Get-Mailbox |where name -Like "HQ Conference*" |Set-CalendarProcessing -AutomateProcessing AutoAccept
#Create Shared Mailboxes
"Sales","Finance","IT Department" | ForEach-Object {
    New-Mailbox -Shared -Name "SM-$_" -OrganizationalUnit $OU
}
#Enable Archive mailboxes on 30 mailboxes
Get-Mailbox -RecipientTypeDetails UserMailbox -ResultSize 30 | Enable-Mailbox -Archive
New-ManagementRoleAssignment -name:Impersonation -Role:ApplicationImpersonation -User:sysadmin