﻿$Cred = Get-Credential
Connect-AzureAD -Credential $Cred

$domain = get-adforest |select upnsuffixes -ExpandProperty upnsuffixes

New-AzureADDomain -Name $domain -IsDefault $true

Set-AzureADDomain -Name lab40976.o365ready.com -IsDefault $true