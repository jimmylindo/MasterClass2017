<#  
    .SYNOPSIS 
    Script that copies the primary emailaddress from proxyAddresses to the userPrincipalName attribute.  
    It runs in test mode and just logs the changes that would have bee done without any parameters.  
    It identifies an exchange user with the legacyExchangeDN-attribute.  
    .PARAMETER Production 
    Runs the script in production mode and makes the actual changes. 
    .NOTES 
    Author: Johan Dahlbom 
    Blog: 365lab.net 
    Email: johan[at]dahlbom.eu 
    The script are provided �AS IS� with no guarantees, no warranties, and they confer no rights.     
#>
param(
    [parameter(Mandatory=$false)]
    [switch]
    $Production = $false
)
#Define variables
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
$DateStamp = Get-Date -Format "yyyy-MM-dd-HH-mm-ss"
$Logfile = $LogFile = ($PSScriptRoot + "\ProxyUPNSync-" + $DateStamp + ".log")
Function Write-JDLog {
    Param ([string]$logstring)
    Add-content $Logfile -value $logstring -Force
    Write-Output $logstring
}
try {
    Import-Module ActiveDirectory -ErrorAction Stop
} catch {
    throw "Module ActiveDirectory not Installed"
}
 
#For each AD-user with a legacyExchangeDN, look up primary SMTP: in proxyAddresses
#and use that as the UPN
$Users=Get-ADObject -LDAPFilter "(&(legacyExchangeDN=*)(objectClass=user))" -Properties ProxyAddresses,distinguishedName,userPrincipalName
 
foreach ($User in $Users) {
    $PrimarySmtpAddress = ($user.ProxyAddresses | Where-Object {$_ -cmatch "^SMTP"}).replace("SMTP:","")
               
    if ($user.userPrincipalName -notmatch $PrimarySmtpAddress) {
        #Run in production mode if the production switch has been used
        if ($Production) {
            Write-JDLog ($user.distinguishedname+ ";" + $user.userPrincipalName + ";NEW:" + $PrimarySmtpAddress)
            Set-ADObject -Identity $user.distinguishedname -Replace @{userPrincipalName = $PrimarySmtpAddress}
        } else {
        #Runs in test mode if the production switch has not been used
            Write-JDLog ($user.distinguishedname + ";" + $user.userPrincipalName + ";NEW:" + $PrimarySmtpAddress)
            Set-ADObject -Identity $user.distinguishedname -WhatIf -Replace @{userPrincipalName = $PrimarySmtpAddress}
        }
    } else {
        Write-Output "Info: All users primary email addresses are matching their userPrincipalName"
    }
}
