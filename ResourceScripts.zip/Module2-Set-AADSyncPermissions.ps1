﻿#Exchange Hybrid writeback
import-module ActiveDirectory
###--------variables
$DN = "OU=ACME,DC=corp,DC=acme,DC=com"
$Account = "corp\svcAADConnect"
 
###--------Bind to AD
 
$sc = (Get-ADRootDSE).SchemaNamingContext
$ob = "CN=ms-Exch-Schema-Version-Pt," + $sc
$ExchangeSchemaVersion = (Get-ADObject $ob -pr rangeUpper).rangeUpper
 
###--------variables
 
<# Switches used in cmds http://technet.microsoft.com/en-us/library/cc771151.aspx /I:S = Specifies the objects to which you are applying the permissions.'S' - The child objects only /G = Grants the permissions that you specify to the user or group WP = Write to a property Permission #>
 
###---Update Attributes
 
if ($ExchangeSchemaVersion -ge 15317)
    {
    #Object type: user
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msDS-ExternalDirectoryObjectID;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchArchiveStatus;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchBlockedSendersHash;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchSafeRecipientsHash;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchSafeSendersHash;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchUCVoiceMailSettings;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchUserHoldPolicies;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;proxyAddresses;user'"
    Invoke-Expression $cmd
 
    #Object type: group
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;proxyAddresses;group'"
    Invoke-Expression $cmd
    #Object type: contact
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;proxyAddresses;contact'"
    Invoke-Expression $cmd
    }
else
    {
    #Object type: user
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchArchiveStatus;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchBlockedSendersHash;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchSafeRecipientsHash;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchSafeSendersHash;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchUCVoiceMailSettings;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;msExchUserHoldPolicies;user'"
    Invoke-Expression $cmd
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;proxyAddresses;user'"
    Invoke-Expression $cmd
 
    #Object type: group
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;proxyAddresses;group'"
    Invoke-Expression $cmd
    #Object type: contact
    $cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;proxyAddresses;contact'"
    Invoke-Expression $cmd
    } 

#Password Sync Permissions
    ###--------variables
 
&lt;# Switches used in cmds http://technet.microsoft.com/en-us/library/cc771151.aspx /G = Grants the permissions that you specify to the user or group CA = Control access If you do not specify {ObjectType | Property} to define the specific extended right for control access, this permission applies to all meaningful control accesses on the object; otherwise, it applies only to the specific extended right for that object. #&gt;
 
$RootDSE = [ADSI]"LDAP://RootDSE"
$DefaultNamingContext = $RootDse.defaultNamingContext
$ConfigurationNamingContext = $RootDse.configurationNamingContext
 
###---Update Attributes
 
#Object type: user
$cmd = "dsacls '$DefaultNamingContext' /G '`"$Account`":CA;`"Replicating Directory Changes`";'"
Invoke-Expression $cmd
$cmd = "dsacls '$DefaultNamingContext' /G '`"$Account`":CA;`"Replicating Directory Changes All`";'"
Invoke-Expression $cmd

#Password-writeback
#Object type: user
 
$cmd = "dsacls '$DN' /I:S /G '`"$Account`":CA;`"Reset Password`";user'"
Invoke-Expression $cmd
$cmd = "dsacls '$DN' /I:S /G '`"$Account`":CA;`"Change Password`";user'"
Invoke-Expression $cmd
$cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;pwdLastSet;user'"
Invoke-Expression $cmd
$cmd = "dsacls '$DN' /I:S /G '`"$Account`":WP;lockoutTime;user'"
Invoke-Expression $cmd