﻿Configuration InstallExchange
{
    param
    (
        [PSCredential]$AdminCreds,
        $ExOrgName
    )

    Import-DscResource -Module xExchange
    Import-DscResource -Module xPendingReboot
    Import-DscResource -Module PSDesiredStateConfiguration

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true   
        }

        #Check if a reboot is needed before installing Exchange
        xPendingReboot BeforeExchangeInstall
        {
            Name      = "BeforeExchangeInstall"
        }


        #Do the Exchange install

        
        xExchInstall InstallExchange
        {
            Path       = "E:\Setup.exe"
            Arguments  = "/mode:Install /role:Mailbox /OrganizationName:MyOrg /TargetDir:"C:\Exchange Server" /IAcceptExchangeServerLicenseTerms"
            Credential = $AdminCreds

            DependsOn  = '[xPendingReboot]BeforeExchangeInstall'
        }

        #See if a reboot is required after installing Exchange
        xPendingReboot AfterExchangeInstall
        {
            Name      = "AfterExchangeInstall"

            DependsOn = '[xExchInstall]InstallExchange'
        }
    }
}


