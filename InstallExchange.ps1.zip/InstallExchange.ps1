﻿Configuration InstallExchange
{
    param
    (
        [PSCredential]$AdminCreds
    )

    Import-DscResource -Module xExchange
    Import-DscResource -Module xPendingReboot
    Import-DscResource -Module PSDesiredStateConfiguration

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true   
        }

	#Check if a reboot is needed before installing Exchange
        xPendingReboot BeforeUCMAInstall
        {
            Name      = "BeforeUCMAInstall"
        }

	#Installs UCMA. Don't forget to change path it if it is required
        Package UCMA
        {
            Ensure= 'Present'
            Name = 'Microsoft Unified Communications Managed API 4.0, Core
                    Runtime 64-bit'
            Path= 'C:\exchangemedia\UcmaRuntimeSetup.exe'
            ProductID= 'ED98ABF5-B6BF-47ED-92AB-1CDCAB964447'
            Arguments= '/q'
            DependsOn  = '[xPendingReboot]BeforeUCMAInstall'
 
         }
        #Check if a reboot is needed before installing Exchange
        xPendingReboot BeforeExchangeInstall
        {
            Name      = "BeforeExchangeInstall"
	        DependsOn = '[Package]UCMA'
        }


        #Do the Exchange install

        
        xExchInstall InstallExchange
        {
            Path       = "F:\Setup.exe"
            Arguments  = "/mode:Install /role:Mailbox /OrganizationName:ACME /IAcceptExchangeServerLicenseTerms"
            Credential = $AdminCreds

            DependsOn  = '[xPendingReboot]BeforeExchangeInstall'
        }

    }
}


